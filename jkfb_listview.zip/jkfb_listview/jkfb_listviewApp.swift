//
//  jkfb_listviewApp.swift
//  jkfb_listview
//
//  Created by ITB103-COMP13 on 5/25/24.
//

import SwiftUI

@main
struct jkfb_listviewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
